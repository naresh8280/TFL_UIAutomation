﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using TFL_Automation.Drivers;
using TFL_Automation.Pages;

namespace TFL_Automation.Tests
{
    public class PlanAJourneyWidgetTests
    {
        IWebDriver driver;

       
        public void ValidJourney() {
            
            PlanAJourneyWidget ValidJourneyWidget = new PlanAJourneyWidget();
            ValidJourneyWidget.InitBrowser();
            ValidJourneyWidget.EnterJourneyDetails("SM2 6AG", "HA3 9RA");
            ValidJourneyWidget.ClickonJourneyButton();
            ValidJourneyWidget.AssertValidJournyResults();

        }

        [Test]
        public void InValidJourney()
        {
            PlanAJourneyWidget InValidJourneyWidget = new PlanAJourneyWidget();
            InValidJourneyWidget.InitBrowser();
            InValidJourneyWidget.EnterJourneyDetails("Testing", "123456789");
            InValidJourneyWidget.ClickonJourneyButton();
 
        }

        public void InValidJourneyResults()
        {
            PlanAJourneyWidget InValidJourneyWidget = new PlanAJourneyWidget();
            InValidJourneyWidget.InValidJourneyResults();

        }

        public void NoJourneyDetailsResults()
        {
            PlanAJourneyWidget JourneyWidget = new PlanAJourneyWidget();

            JourneyWidget.NoJourneyDetailsResults();

        }

        //Edit Journey 

        public void ValidJourneyResultsPage()
        {

            PlanAJourneyWidget ValidJourneyWidget = new PlanAJourneyWidget();
            ValidJourneyWidget.InitBrowser();
            ValidJourneyWidget.EnterJourneyDetails("SM2 6AG", "HA3 9RA");
            ValidJourneyWidget.ClickonJourneyButton();
            
        }
        public void EditJourney()
        {
            JourneyResultsAndEditJourney EditToField = new JourneyResultsAndEditJourney();
            EditToField.EditJourney("HA3 8NT");

        }

        public void EditJourneySubmit()
        {
            JourneyResultsAndEditJourney EditToFieldSubmit = new JourneyResultsAndEditJourney();
            EditToFieldSubmit.EditJourneySubmit();
        }

        internal void AssertEditJournyResults()
        {
            throw new NotImplementedException();
        }
    }
}
