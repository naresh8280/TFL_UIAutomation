﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;


namespace TFL_Automation.Drivers
{
    public class InvokeBrowser
    {
        public IWebDriver driver;
        public void InitBrowser(string from, string to)
        {
            driver = new ChromeDriver();

            driver.Navigate().GoToUrl("https://tfl.gov.uk");
            driver.Manage().Window.Maximize();
            driver.FindElement(By.Id("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll")).Click();
            driver.FindElement(By.CssSelector("#cb-confirmedSettings > #cb-buttons > .cb-button > strong")).Click();

        }


    }
}
