﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using TFL_Automation.Drivers;
using TFL_Automation.Pages;
using TFL_Automation.Tests;

namespace TFL_Automation.Steps
{
    [Binding]
   public class PlanAJourneySteps:InvokeBrowser
    {
        IWebDriver driver = null;
        
        [Given(@"I navigate to tfl\.gov\.uk")]
        public void GivenINavigateToTfl_Gov_Uk()
        {
            PlanAJourneyWidget navigateToTFL = new PlanAJourneyWidget();
            navigateToTFL.InitBrowser();
            
        }

        [When(@"I enter valid journey details")]
        public void WhenIEnterValidJourneyDetails()
        {

            PlanAJourneyWidget navigateToTFL = new PlanAJourneyWidget();
            navigateToTFL.EnterJourneyDetails("SM2 6AG", "HA3 9RA");
        }

       [When(@"I click Plan my journey button")]
        public void WhenIClickPlanMyJourneyButton()
        {
            PlanAJourneyWidget test = new PlanAJourneyWidget();
            test.ClickonJourneyButton();
        }

        [Then(@"I see the results")]
        public void ThenISeeTheResults()
        {
            PlanAJourneyWidget JourneyResults = new PlanAJourneyWidget();
            JourneyResults.AssertValidJournyResults();

        }

        [When(@"I enter invalid journey details")]
        public void WhenIEnterInvalidJourneyDetails()
        {
            PlanAJourneyWidgetTests WidgetTests = new PlanAJourneyWidgetTests();
            WidgetTests.InValidJourney();
        }

        [Then(@"I don't see the results")]
        public void ThenIDonTSeeTheResults()
        {
            PlanAJourneyWidgetTests WidgetTests = new PlanAJourneyWidgetTests();
            WidgetTests.InValidJourneyResults();
        }

        [Then(@"I see error messages")]
        public void ThenISeeErrorMessages()
        {
            PlanAJourneyWidgetTests WidgetTests = new PlanAJourneyWidgetTests();
            WidgetTests.NoJourneyDetailsResults();
        }

        //Edit Journey
        [Given(@"I'm on journey results page")]
        public void GivenIMOnJourneyResultsPage()
        {
            PlanAJourneyWidgetTests WidgetTests = new PlanAJourneyWidgetTests();
            WidgetTests.ValidJourneyResultsPage();
        }

        [When(@"I edit to field")]
        public void WhenIEditToField()
        {
            PlanAJourneyWidgetTests WidgetTests = new PlanAJourneyWidgetTests();
            WidgetTests.EditJourney();
        }

        [Then(@"I see amended journey results")]
        public void ThenISeeAmendedJourneyResults()
        {
            PlanAJourneyWidgetTests WidgetTests = new PlanAJourneyWidgetTests();
            WidgetTests.AssertEditJournyResults();
        }



        [When(@"I click Recents button")]
        public void WhenIClickRecentsButton()
        {
            ScenarioContext.Current.Pending();
        }

        [Then(@"I see a list of recently planned journeys")]
        public void ThenISeeAListOfRecentlyPlannedJourneys()
        {
            ScenarioContext.Current.Pending();
        }


    }
}
