﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using TFL_Automation.Drivers;

namespace TFL_Automation.Pages
{
    
    public class PlanAJourneyWidget
    {
      
        public IWebDriver driver;
        
        
       public void InitBrowser()
        {
            driver = new ChromeDriver();
            
            driver.Navigate().GoToUrl("https://tfl.gov.uk");
            driver.Manage().Window.Maximize();
            driver.FindElement(By.Id("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll")).Click();
            driver.FindElement(By.CssSelector("#cb-confirmedSettings > #cb-buttons > .cb-button > strong")).Click();

        }

       
        public void EnterJourneyDetails(string from, string to)
        {
            driver.FindElement(By.Id("InputFrom")).SendKeys(from); 
            driver.FindElement(By.Name("InputTo")).SendKeys(to);

        }

        public void ClickonJourneyButton()
        {
            driver.FindElement(By.Id("plan-journey-button")).Click();
        }

        public void InputFromError()
        {
            driver.FindElement(By.Id("InputFrom - error"));
        }

       //Assertion for valid journey
        public void AssertValidJournyResults(){

            IWebElement body = driver.FindElement(By.CssSelector("#option-1-content > .journey-details"));
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            Assert.IsTrue(body.Text.Contains("HA3 9RA"));
        }

        //Assertion for Invalid journey
        public void InValidJourneyResults()
        {
            IWebElement testExists = driver.FindElement(By.CssSelector(".field - validation - errors > .field - validation - error"));
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            Assert.IsTrue(testExists.Text.Contains("Sorry, we can't find a journey matching your criteria"));
        }

        //Assertion for no journey details
        public void NoJourneyDetailsResults()
        {
            IWebElement testExists = driver.FindElement(By.Id("InputFrom-error"));
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            Assert.IsTrue(testExists.Text.Contains("InputFrom-error"));
        }

        
    }
}
