﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;

namespace TFL_Automation.Pages
{
    class JourneyResultsAndEditJourney
    {
        public IWebDriver driver;
        public void EditJourney(string to)
        {
            driver.FindElement(By.ClassName("edit-journey")).Click();
            driver.FindElement(By.TagName("Clear To location")).Click();
            driver.FindElement(By.Id("InputTo")).SendKeys(to);
        }

        public void EditJourneySubmit()
        {
            driver.FindElement(By.Id("plan-journey-button")).Click();
        }

        //Assertion for edit journey
        public void AssertEditJournyResults()
        {

            IWebElement body = driver.FindElement(By.CssSelector("#option-1-content > .journey-details"));
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            Assert.IsTrue(body.Text.Contains("HA3 8NT"));
        }
        
    }
}
